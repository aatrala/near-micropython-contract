/*
 * BEGIN
 * File name: objmap.c
 * Date: 2025-01-21
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/

#include <stdlib.h>
#include <assert.h>

#include "py/runtime.h"

typedef struct _mp_obj_map_t {
    mp_obj_base_t base;
    size_t n_iters;
    mp_obj_t fun;
    mp_obj_t iters[];
} mp_obj_map_t;

static mp_obj_t map_make_new(const mp_obj_type_t *type, size_t n_args, size_t n_kw, const mp_obj_t *args) {
    mp_arg_check_num(n_args, n_kw, 2, MP_OBJ_FUN_ARGS_MAX, false);
    mp_obj_map_t *o = mp_obj_malloc_var(mp_obj_map_t, iters, mp_obj_t, n_args - 1, type);
    o->n_iters = n_args - 1;
    o->fun = args[0];
    for (size_t i = 0; i < n_args - 1; i++) {
        o->iters[i] = mp_getiter(args[i + 1], NULL);
    }
    return MP_OBJ_FROM_PTR(o);
}

static mp_obj_t map_iternext(mp_obj_t self_in) {
    mp_check_self(mp_obj_is_type(self_in, &mp_type_map));
    mp_obj_map_t *self = MP_OBJ_TO_PTR(self_in);
    mp_obj_t *nextses = m_new(mp_obj_t, self->n_iters);

    for (size_t i = 0; i < self->n_iters; i++) {
        mp_obj_t next = mp_iternext(self->iters[i]);
        if (next == MP_OBJ_STOP_ITERATION) {
            m_del(mp_obj_t, nextses, self->n_iters);
            return MP_OBJ_STOP_ITERATION;
        }
        nextses[i] = next;
    }
    return mp_call_function_n_kw(self->fun, self->n_iters, 0, nextses);
}

MP_DEFINE_CONST_OBJ_TYPE(
    mp_type_map,
    MP_QSTR_map,
    MP_TYPE_FLAG_ITER_IS_ITERNEXT,
    make_new, map_make_new,
    iter, map_iternext
    );

/* END OF FILE: objmap.c */

/*
 * BEGIN
 * File name: cstack.h
 * Date: 2025-01-21
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/

#ifndef MICROPY_INCLUDED_PY_CSTACK_H
#define MICROPY_INCLUDED_PY_CSTACK_H

#include "py/mpstate.h"

// Both init functions below accept the full stack size. Set the
// MICROPY_STACK_CHECK_MARGIN to the number of bytes subtracted to account
// for stack usage between checks.

void mp_cstack_init_with_sp_here(size_t stack_size);

inline static void mp_cstack_init_with_top(void *top, size_t stack_size) {
    MP_STATE_THREAD(stack_top) = (char *)top;

    #if MICROPY_STACK_CHECK
    assert(stack_size > MICROPY_STACK_CHECK_MARGIN); // Should be enforced by port
    MP_STATE_THREAD(stack_limit) = stack_size - MICROPY_STACK_CHECK_MARGIN;
    #else
    (void)stack_size;
    #endif
}

mp_uint_t mp_cstack_usage(void);

#if MICROPY_STACK_CHECK

void mp_cstack_check(void);

#else

inline static void mp_cstack_check(void) {
    // No-op when stack checking is disabled
}

#endif

#endif // MICROPY_INCLUDED_PY_CSTACK_H

/* END OF FILE: cstack.h */

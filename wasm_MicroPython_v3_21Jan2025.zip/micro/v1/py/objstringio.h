/*
 * BEGIN
 * File name: objstringio.h
 * Date: 2025-01-21
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/

#ifndef MICROPY_INCLUDED_PY_OBJSTRINGIO_H
#define MICROPY_INCLUDED_PY_OBJSTRINGIO_H

#include "py/obj.h"

typedef struct _mp_obj_stringio_t {
    mp_obj_base_t base;
    vstr_t *vstr;
    // StringIO has single pointer used for both reading and writing
    mp_uint_t pos;
    // Underlying object buffered by this StringIO
    mp_obj_t ref_obj;
} mp_obj_stringio_t;

#endif // MICROPY_INCLUDED_PY_OBJSTRINGIO_H

/* END OF FILE: objstringio.h */


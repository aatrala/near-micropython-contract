/*
 * BEGIN
 * File name: stackctrl.h
 * Date: 2025-01-21
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/

#ifndef MICROPY_INCLUDED_PY_STACKCTRL_H
#define MICROPY_INCLUDED_PY_STACKCTRL_H

// This API is deprecated, please use py/cstack.h instead

#include "py/mpconfig.h"

#if !MICROPY_PREVIEW_VERSION_2

void mp_stack_ctrl_init(void);
void mp_stack_set_top(void *top);
mp_uint_t mp_stack_usage(void);

#if MICROPY_STACK_CHECK

void mp_stack_set_limit(mp_uint_t limit);
void mp_stack_check(void);
#define MP_STACK_CHECK() mp_stack_check()

#else

#define mp_stack_set_limit(limit) (void)(limit)
#define MP_STACK_CHECK()

#endif // MICROPY_STACK_CHECK

#endif // !MICROPY_PREVIEW_VERSION_2

#endif // MICROPY_INCLUDED_PY_STACKCTRL_H
  
/* END OF FILE: stackctrl.h */

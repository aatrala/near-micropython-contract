/*
 * BEGIN
 * File name: mpstate.c
 * Date: 2025-01-21
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/

#include "py/mpstate.h"

#if MICROPY_DYNAMIC_COMPILER
mp_dynamic_compiler_t mp_dynamic_compiler = {0};
#endif

mp_state_ctx_t mp_state_ctx;

/* END OF FILE: mpstate.c */

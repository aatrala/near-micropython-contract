/*
 * BEGIN
 * File name: parsenumbase.h
 * Date: 2025-01-21
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/

#ifndef MICROPY_INCLUDED_PY_PARSENUMBASE_H
#define MICROPY_INCLUDED_PY_PARSENUMBASE_H

#include "py/mpconfig.h"

size_t mp_parse_num_base(const char *str, size_t len, int *base);

#endif // MICROPY_INCLUDED_PY_PARSENUMBASE_H

/* END OF FILE: parsenumbase.h */

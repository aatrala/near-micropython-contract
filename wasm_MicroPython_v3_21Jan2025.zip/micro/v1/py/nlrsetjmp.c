/*
 * BEGIN
 * File name: nlrsetjmp.c
 * Date: 2025-01-21
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/

#include "py/mpstate.h"

#if MICROPY_NLR_SETJMP

void nlr_jump(void *val) {
    MP_NLR_JUMP_HEAD(val, top);
    longjmp(top->jmpbuf, 1);
}

#endif

/* END OF FILE: nlrsetjmp.c */

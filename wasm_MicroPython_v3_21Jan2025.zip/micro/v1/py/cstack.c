/*
 * BEGIN
 * File name: cstack.c
 * Date: 2025-01-21
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/

#include "py/runtime.h"
#include "py/cstack.h"

void mp_cstack_init_with_sp_here(size_t stack_size) {
    #if __GNUC__ >= 13
    #pragma GCC diagnostic push
    #pragma GCC diagnostic ignored "-Wdangling-pointer"
    #endif
    volatile int stack_dummy;
    mp_cstack_init_with_top((void *)&stack_dummy, stack_size);
    #if __GNUC__ >= 13
    #pragma GCC diagnostic pop
    #endif
}

mp_uint_t mp_cstack_usage(void) {
    // Assumes descending stack
    volatile int stack_dummy;
    return MP_STATE_THREAD(stack_top) - (char *)&stack_dummy;
}

#if MICROPY_STACK_CHECK

void mp_cstack_check(void) {
    if (mp_cstack_usage() >= MP_STATE_THREAD(stack_limit)) {
        mp_raise_recursion_depth();
    }
}

#endif // MICROPY_STACK_CHECK

/* END OF FILE: cstack.c */

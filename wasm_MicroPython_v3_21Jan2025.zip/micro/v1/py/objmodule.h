/*
 * BEGIN
 * File name: objmodule.h
 * Date: 2025-01-21
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/

#ifndef MICROPY_INCLUDED_PY_OBJMODULE_H
#define MICROPY_INCLUDED_PY_OBJMODULE_H

#include "py/obj.h"

#ifndef NO_QSTR
// Only include module definitions when not doing qstr extraction, because the
// qstr extraction stage also generates this module definition header file.
#include "genhdr/moduledefs.h"
#endif

extern const mp_map_t mp_builtin_module_map;
extern const mp_map_t mp_builtin_extensible_module_map;

mp_obj_t mp_module_get_builtin(qstr module_name, bool extensible);

void mp_module_generic_attr(qstr attr, mp_obj_t *dest, const uint16_t *keys, mp_obj_t *values);

#endif // MICROPY_INCLUDED_PY_OBJMODULE_H

/* END OF FILE: objmodule.h */

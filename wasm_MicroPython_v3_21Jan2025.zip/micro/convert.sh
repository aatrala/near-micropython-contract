#!/bin/bash

# Get today's date
today=$(date +"%Y-%m-%d")

# Output file
output_file="combined_output.txt"

# Process each file
for file in *; do
  if [[ -f "$file" ]]; then
    sed -e "/\/\*/,/\*\//{
      H;d
    }
    x
    /copyright/I {
      s/.*/\/\*\n  \*  BEGIN\n   \* File name: ${file}\n   \* Date: ${today}\n   \* Version: v1.0\n   \* \n   \* Converted to WASM \/ Near Blockchain format\n   \*\n   \* END\n\*\//
    }
    x" "$file" >> "$output_file"
  fi
done


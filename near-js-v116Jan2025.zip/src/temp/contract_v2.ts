// contract.ts
import { NearBindgen, near, call, view } from 'near-sdk-js';

declare function mp_js_init(): void;
declare function mp_js_do_exec(code: string): string;

@NearBindgen({})
class MicroPythonContract {
    constructor() {
        // Initialize MicroPython when contract is deployed
        try {
            // Add logging to see what's happening
            near.log("Calling mp_js_init function...");

            mp_js_init();
        } catch (error) {
            // Log any errors
            near.log("Error in mp_js_init: " + error.toString());
            throw error;
        }

    }

    @call({})
    say_hello(): string {
        // Python code to execute
        const pythonCode = `
def say_hello():
    return "Hello World"

result = say_hello()
`;
        
        try {
            // Execute the Python code

            // Add logging to see what's happening
            near.log("Calling say_hello function...");

            const result = mp_js_do_exec(pythonCode);
            return result;
        } catch (error) {
            near.log(`Error executing Python code: ${error}`);
            throw error;
        }
    }
}



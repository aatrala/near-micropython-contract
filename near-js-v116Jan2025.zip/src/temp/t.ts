import { NearBindgen, near, call, view } from 'near-sdk-js';


// Example of a precompiled and optimized WASM binary
// Ensure that this WASM binary is optimized using tools like wasm-opt before embedding it here

// Your actual precompiled WASM bytecode goes here, e.g., [0, 97, 115, ...]

const wasmBinary: Uint8Array = new Uint8Array([0,97,115,109]);

// Define the interface for MicroPython WASM imports
interface MicroPythonImports extends WebAssembly.Imports {
  env: {
    mp_js_write: (ptr: number, len: number) => string;
    mp_js_error: (ptr: number, len: number) => void;
    [key: string]: any;
  };
  [key: string]: any;
}

// Define the interface for MicroPython WASM exports
interface MicroPythonExports extends WebAssembly.Exports {
  memory: WebAssembly.Memory;
  mp_js_init: () => void;
  mp_js_do_exec: (ptr: number) => string;
  malloc?: (size: number) => number;
  free?: (ptr: number) => void;
}

interface MicroPythonInstance extends WebAssembly.Instance {
  exports: MicroPythonExports;
}

// Load the WASM binary synchronously and instantiate the module
let wasmInstance: MicroPythonInstance | null = null;

// Initialize WASM module synchronously (called during contract instantiation)
function initializeWasmInstance(): void {
  if (wasmInstance) return; // Already initialized

  try {
    // Create WebAssembly module from the binary
    const wasmModule = new WebAssembly.Module(wasmBinary);
    
    // Define imports for the WASM module
    const imports: MicroPythonImports = {
      env: {
        mp_js_write: (ptr: number, len: number) => {
          const memory = wasmInstance!.exports.memory;
          const bytes = new Uint8Array(memory.buffer, ptr, len);
          return new TextDecoder().decode(bytes);
        },
        mp_js_error: (ptr: number, len: number) => {
          const memory = wasmInstance!.exports.memory;
          const bytes = new Uint8Array(memory.buffer, ptr, len);
          throw new Error(new TextDecoder().decode(bytes));
        }
      }
    };

    // Instantiate the WebAssembly module with the imports
    wasmInstance = new WebAssembly.Instance(wasmModule, imports) as MicroPythonInstance;

    // Call the initialization function in the WASM module (if necessary)
    wasmInstance.exports.mp_js_init();
  } catch (error) {
    console.error('Error initializing WebAssembly instance:', error);
    throw error;
  }
}

// Convert string to UTF8 bytes
function stringToUTF8Array(str: string): Uint8Array {
  const encoder = new TextEncoder();
  return encoder.encode(str);
}

// Execute Python code with proper memory management
function executePythonCode(instance: MicroPythonInstance, code: string): string {
  if (!instance.exports.malloc || !instance.exports.free) {
    throw new Error("Memory management functions not available");
  }

  const bytes = stringToUTF8Array(code);
  const len = bytes.length;
  const ptr = instance.exports.malloc(len + 1);

  try {
    const memory = new Uint8Array(instance.exports.memory.buffer);
    memory.set(bytes, ptr);
    memory[ptr + len] = 0; // null terminator
    return instance.exports.mp_js_do_exec(ptr);
  } finally {
    instance.exports.free(ptr);
  }
}

// Centralized error handling for logs
function logError(message: string, error: Error): void {
  near.log(`${message}: ${error.message}`);
  throw error;
}

// Contract class definition
@NearBindgen({})
class MicroPythonContract {
  constructor() {
    // Initialize the WASM instance synchronously on contract initialization
    initializeWasmInstance();
  }

  @call({})
  say_hello(): string {
    const pythonCode = `
def say_hello():
    return "Hello World"

result = say_hello()
`;

    try {
      return executePythonCode(wasmInstance!, pythonCode);
    } catch (error) {
      logError("Error executing Python code", error);
      throw error;
    }
  }

  @call({})
  check_exports(): string {
    try {
      const exports = Object.keys(wasmInstance!.exports);
      near.log("Available exports: " + JSON.stringify(exports));
      return JSON.stringify(exports);
    } catch (error) {
      logError("Error fetching exports", error);
      throw error;
    }
  }
}



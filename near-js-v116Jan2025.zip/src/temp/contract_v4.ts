// contract.ts
import { NearBindgen, near, call, view } from 'near-sdk-js';

// Load the MicroPython WASM module
const wasmPath = './micropython.wasm';
let micropythonInstance: any = null;

function stringToUTF8Array(str: string): Uint8Array {
    const encoder = new TextEncoder();
    return encoder.encode(str);
}

function allocateString(str: string): number {
    const bytes = stringToUTF8Array(str);
    const len = bytes.length;
    
    // Allocate memory in WASM
    const ptr = micropythonInstance.exports.malloc(len + 1);  // +1 for null terminator
    
    // Write the string to WASM memory
    const memory = new Uint8Array(micropythonInstance.exports.memory.buffer);
    memory.set(bytes, ptr);
    memory[ptr + len] = 0;  // Add null terminator
    
    return ptr;
}

async function loadMicroPython() {
    if (!micropythonInstance) {
        try {
            const wasmModule = await WebAssembly.instantiateStreaming(fetch(wasmPath), {
                env: {
                    mp_js_write: (ptr: number, len: number) => {
                        const memory = micropythonInstance.exports.memory;
                        const bytes = new Uint8Array(memory.buffer, ptr, len);
                        return new TextDecoder().decode(bytes);
                    },
                    mp_js_error: (ptr: number, len: number) => {
                        const memory = micropythonInstance.exports.memory;
                        const bytes = new Uint8Array(memory.buffer, ptr, len);
                        throw new Error(new TextDecoder().decode(bytes));
                    }
                }
            });
            
            micropythonInstance = wasmModule.instance;
            micropythonInstance.exports.mp_js_init();
        } catch (error) {
            near.log(`Failed to load MicroPython: ${error}`);
            throw error;
        }
    }
    return micropythonInstance;
}

@NearBindgen({})
class HelloWorld {
    constructor() {
        this.initializeMicroPython();
    }

    private async initializeMicroPython() {
        try {
            near.log(`calling load micropython`);
            await loadMicroPython();
        } catch (error) {
            near.log(`Failed to initialize MicroPython: ${error}`);
            throw error;
        }
    }

    @call({})
    say_hello(): string {
        if (!micropythonInstance) {
            throw new Error("MicroPython not initialized");
        }

        const pythonCode = `
def say_hello():
    return "Hello World"

result = say_hello()
`;
        
        try {
            // Allocate memory for the Python code string
            const codePtr = allocateString(pythonCode);
            
            near.log(`calling mp_js_do_exec function`);

            // Execute the Python code
            const result = micropythonInstance.exports.mp_js_do_exec(codePtr);
            
            // Free the allocated memory
            micropythonInstance.exports.free(codePtr);
            
            return result;
        } catch (error) {
            near.log(`Error executing Python code: ${error}`);
            throw error;
        }
    }
}



import { NearBindgen, near, call, view } from 'near-sdk-js';

// This binary will be loaded once and reused across all instances
let wasmBinary: Uint8Array | null = null;

// Function to lazily load the WASM binary
function getWasmBinary(): Uint8Array {
    if (!wasmBinary) {
        //wasmBinary = new Uint8Array([]);  // Load your actual WASM binary here

        //Load your actual WASM binary here
             wasmBinary = new Uint8Array([0,97,115]);
    }
    return wasmBinary;
}

// Define the interface for MicroPython WASM imports
interface MicroPythonImports extends WebAssembly.Imports {
    env: {
        mp_js_write: (ptr: number, len: number) => string;
        mp_js_error: (ptr: number, len: number) => void;
        [key: string]: any;
    };
    [key: string]: any;
}

// Define the interface for MicroPython WASM exports
interface MicroPythonExports extends WebAssembly.Exports {
    memory: WebAssembly.Memory;
    mp_js_init: () => void;
    mp_js_do_exec: (ptr: number) => string;
    malloc?: (size: number) => number;
    free?: (ptr: number) => void;
}

interface MicroPythonInstance extends WebAssembly.Instance {
    exports: MicroPythonExports;
}

// Convert string to UTF8 bytes
function stringToUTF8Array(str: string): Uint8Array {
    const encoder = new TextEncoder();
    return encoder.encode(str);
}

// Centralized error handling for logs
function logError(message: string, error: Error): void {
    near.log(`${message}: ${error.message}`);
    throw error;
}

// Execute Python code with proper memory management
function executePythonCode(instance: MicroPythonInstance, code: string): string {
    if (!instance.exports.malloc || !instance.exports.free) {
        throw new Error("Memory management functions not available");
    }

    const bytes = stringToUTF8Array(code);
    const len = bytes.length;
    const ptr = instance.exports.malloc(len + 1);

    try {
        const memory = new Uint8Array(instance.exports.memory.buffer);
        memory.set(bytes, ptr);
        memory[ptr + len] = 0; // null terminator
        return instance.exports.mp_js_do_exec(ptr);
    } finally {
        instance.exports.free(ptr);
    }
}

@NearBindgen({})
class MicroPythonContract {
    private wasmInstance: MicroPythonInstance | null = null; // Initialize to null

    constructor() {
        // Ensure wasmInstance is initialized as null
        this.wasmInstance = null;
    }

    // Lazy initialization of WASM instance to improve startup time
    private initWasmInstance(): void {
        if (this.wasmInstance) return; // Avoid re-initialization

        try {
            const imports: MicroPythonImports = {
                env: {
                    mp_js_write: (ptr: number, len: number) => {
                        const memory = this.wasmInstance!.exports.memory;
                        const bytes = new Uint8Array(memory.buffer, ptr, len);
                        return new TextDecoder().decode(bytes);
                    },
                    mp_js_error: (ptr: number, len: number) => {
                        const memory = this.wasmInstance!.exports.memory;
                        const bytes = new Uint8Array(memory.buffer, ptr, len);
                        throw new Error(new TextDecoder().decode(bytes));
                    }
                }
            };

            const wasmModule = new WebAssembly.Module(getWasmBinary());
            this.wasmInstance = new WebAssembly.Instance(wasmModule, imports) as MicroPythonInstance;
            this.wasmInstance.exports.mp_js_init();
        } catch (error) {
            logError("Failed to initialize WASM", error);
        }
    }

    @call({})
    say_hello(): string {
        this.initWasmInstance(); // Ensure WASM instance is initialized

        const pythonCode = `
def say_hello():
    return "Hello World"

result = say_hello()
`;

        try {
            return executePythonCode(this.wasmInstance!, pythonCode);
        } catch (error) {
            logError("Error executing Python code", error);
            throw error;
        }
    }

    @call({})
    check_exports(): string {
        this.initWasmInstance(); // Ensure WASM instance is initialized

        const exports = Object.keys(this.wasmInstance!.exports);
        near.log("Available exports: " + JSON.stringify(exports));
        return JSON.stringify(exports);
    }
}

// Python source code
const pythonCode = `def say_hello_world():
    return "Hello, World!"

def say_hello():
    return "Hello!" ;

def say_hello_by_name(name):
    return "Hello, " + name;

def add_numbers(a, b):
    return a + b

print ("Hello, world");
print ("sum is ", add_numbers(20, 30));

print (say_hello("aatral"));
`;



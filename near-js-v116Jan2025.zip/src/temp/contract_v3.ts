// contract.ts
import { NearBindgen, near, call, view } from 'near-sdk-js';

// Load the MicroPython WASM module
const wasmPath = './wasm/micropython.wasm';
let micropythonInstance: any = null;

function loadMicroPython() {
    if (!micropythonInstance) {
        try {
            const wasmModule = await WebAssembly.instantiateStreaming(fetch(wasmPath), {
                env: {
                    // Add any required environment functions that MicroPython expects
                    mp_js_write: (ptr: number, len: number) => {
                        // Implementation for handling Python output
                        const memory = micropythonInstance.exports.memory;
                        const bytes = new Uint8Array(memory.buffer, ptr, len);
                        return new TextDecoder().decode(bytes);
                    },
                    mp_js_error: (ptr: number, len: number) => {
                        // Implementation for handling Python errors
                        const memory = micropythonInstance.exports.memory;
                        const bytes = new Uint8Array(memory.buffer, ptr, len);
                        throw new Error(new TextDecoder().decode(bytes));
                    }
                }
            });
            
            micropythonInstance = wasmModule.instance;
            
            // Now we can safely call mp_js_init from the WASM instance
            micropythonInstance.exports.mp_js_init();
        } catch (error) {
            near.log(`Failed to load MicroPython: ${error}`);
            throw error;
        }
    }
    return micropythonInstance;
}

@NearBindgen({})
class HelloWorld {
    constructor() {
        // Initialize MicroPython when contract is loaded
        this.initializeMicroPython();
    }

    private initializeMicroPython() {
        try {
            near.log("Calling mp_js_init function...");
            await loadMicroPython();
        } catch (error) {
            near.log(`Failed to initialize MicroPython: ${error}`);
            throw error;
        }
    }

    @call({})
    say_hello(): string {
        if (!micropythonInstance) {
            throw new Error("MicroPython not initialized");
        }

        const pythonCode = `print("hello, world")`;

        
        try {
            near.log(`calling mp_js_do_exec code: ');

            // Use the WASM instance's exports to call mp_js_do_exec
            const result = micropythonInstance.exports.mp_js_do_exec(pythonCode);
            return result;
        } catch (error) {
            near.log(`Error executing Python code: ${error}`);
            throw error;
        }
    }
}



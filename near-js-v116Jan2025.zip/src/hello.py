def say_hello_world():
    return "Hello, World!"

def say_hello():
    return "Hello!" ;

def say_hello_by_name(name):
    return "Hello, " + name;

def add_numbers(a, b):
    return a + b

print ("Hello, world");
print ("sum is ", add_numbers(20, 30));

print (say_hello("aatral"));

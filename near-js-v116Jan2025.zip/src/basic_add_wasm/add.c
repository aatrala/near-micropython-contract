// Example WASM Module (add.c)

#include <stdio.h>

int add(int a, int b) {
   return a + b;
}

int main() {
    printf("%d", add(2,3));
     return 0;
}

// Example WASM Module (add.c)
// #include <stdio.h>

// int add(int a, int b) {
//   return a + b;
// }

// int main() {
//     printf("%d", add(2,3));
//     return 0;
// }

// compile with emcc: emcc add.c -o module.wasm -O3 -s EXPORTED_FUNCTIONS=['_add'] -s "EXPORT_ES6=1" -s MODULARIZE=1 -s "ENVIRONMENT='node'"


//emcc add.c -o module.wasm -O3 -s EXPORTED_FUNCTIONS=['_add'] -s "EXPORT_ES6=1" -s MODULARIZE=1 -s "ENVIRONMENT='node'"


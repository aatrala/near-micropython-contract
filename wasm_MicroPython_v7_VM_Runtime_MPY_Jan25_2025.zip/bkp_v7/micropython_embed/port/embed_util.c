/* BEGIN OF FILE: embed_util.c */

#ifdef MICROPY_WASM_LIBRARY_CLANG
#include <string.h>
#else
#include <string.h>
#endif

#include "py/micropython.h"
#include "port/micropython_embed.h"

//#include "py/compile.h"
//#include "py/persistentcode.h"
//#include "py/runtime.h"
//#include "py/stackctrl.h"


#ifdef MICROPY_WASM_LIBRARY
extern void near_log_message(const char *msg);
#endif

// Initialise the runtime.
void mp_embed_init(void *gc_heap, size_t gc_heap_size, void *stack_top) 
{

#ifdef MICROPY_WASM_OBJECT_ORIENTED

#ifdef MICROPY_WASM_OBJECT_MP_TYPE_MODULE
    global_init_const_mp_type_module();
#endif

    global_init_mp_state_ctx();
    global_init_mp_module_main();

#ifdef MICROPY_WASM_OBJECT_MP_TYPE_IO 
    global_init_const_mp_module_io();
#endif

#ifdef MICROPY_WASM_OBJECT_MP_TYPE_JSON 
    global_init_const_mp_module_json();
#endif

#ifdef MICROPY_WASM_OBJECT_MP_TYPE_BUILTINS 
    global_init_const_mp_module_builtins();
#endif


#ifdef MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_TABLE  
    global_init_const_mp_builtin_module_table();
#endif

#ifdef MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_MAP
    global_init_const_mp_builtin_module_map();
#endif


#endif

    mp_stack_set_top(stack_top);

#ifdef MICROPY_WASM_LIBRARY
    near_log_message("before gc_init");
#endif    

#ifdef MICROPY_ENABLE_GC
    //gc_init(gc_heap, (uint8_t *)gc_heap + gc_heap_size);
#endif

#ifdef MICROPY_WASM_LIBRARY
    near_log_message("before mp_init");
#endif

#ifdef MICROPY_WASM_LIBRARY
    near_log_message("commented mp_init");
#else
    mp_init();
#endif

}

#if MICROPY_ENABLE_COMPILER
// Compile and execute the given source script (Python text).
void mp_embed_exec_str(const char *src) {
    nlr_buf_t nlr;
    if (nlr_push(&nlr) == 0) {
        // Compile, parse and execute the given string.
        mp_lexer_t *lex = mp_lexer_new_from_str_len(MP_QSTR__lt_stdin_gt_, src, strlen(src), 0);
        qstr source_name = lex->source_name;
        mp_parse_tree_t parse_tree = mp_parse(lex, MP_PARSE_FILE_INPUT);
        mp_obj_t module_fun = mp_compile(&parse_tree, source_name, true);
        mp_call_function_0(module_fun);
        nlr_pop();
    } else {
        // Uncaught exception: print it out.
        mp_obj_print_exception(&mp_plat_print, (mp_obj_t)nlr.ret_val);
    }
}
#endif

//#if MICROPY_PERSISTENT_CODE_LOAD
void mp_embed_exec_mpy(const uint8_t *mpy, size_t len) 
{
    nlr_buf_t nlr;
    if (nlr_push(&nlr) == 0) {
        // Execute the given .mpy data.
        mp_module_context_t *ctx = m_new_obj(mp_module_context_t);
        ctx->module.globals = mp_globals_get();
        mp_compiled_module_t cm;
        cm.context = ctx;
        mp_raw_code_load_mem(mpy, len, &cm);
        mp_obj_t f = mp_make_function_from_proto_fun(cm.rc, ctx, MP_OBJ_NULL);
        mp_call_function_0(f);
        nlr_pop();
    } else {
        // Uncaught exception: print it out.
        mp_obj_print_exception(&mp_plat_print, (mp_obj_t)nlr.ret_val);
    }
}
//#endif

// Deinitialise the runtime.
void mp_embed_deinit(void) {

#ifdef MICROPY_WASM_OBJECT_ORIENTED

#ifdef MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_MAP
    global_deinit_const_mp_builtin_module_map();
#endif

#ifdef MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_TABLE  
    global_deinit_const_mp_builtin_module_table();
#endif
#ifdef MICROPY_WASM_OBJECT_MP_TYPE_BUILTINS 
    global_deinit_const_mp_module_builtins();
#endif

#ifdef MICROPY_WASM_OBJECT_MP_TYPE_MODULE
    global_deinit_const_mp_type_module();
#endif


#ifdef MICROPY_WASM_OBJECT_MP_TYPE_JSON 
    global_deinit_const_mp_module_json();
#endif

#ifdef MICROPY_WASM_OBJECT_MP_TYPE_IO 
    global_deinit_const_mp_module_io();
#endif

    global_deinit_mp_state_ctx();
    global_deinit_mp_module_main();
#endif

    mp_deinit();
}

#if MICROPY_ENABLE_GC
// Run a garbage collection cycle.
void gc_collect(void) {
    gc_collect_start();
    gc_helper_collect_regs_and_stack();
    gc_collect_end();
}
#endif

// Called if an exception is raised outside all C exception-catching handlers.
void nlr_jump_fail(void *val) {
    for (;;) {
    }
}

#ifndef NDEBUG
// Used when debugging is enabled.
void __assert_func(const char *file, int line, const char *func, const char *expr) {
    for (;;) {
    }
}
#endif
/* END OF FILE: embed_util.c */

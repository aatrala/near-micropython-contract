#include <stdio.h>

const int x __attribute__((section(".mysection"))) = 42;

int main() {
    printf("Value of x: %d\n", x);
    return 0;
}


#include <gcc-plugin.h>
#include <plugin-version.h>
#include <tree.h>
#include <tree-pass.h>
#include <stringpool.h>
#include <cgraph.h>
#include <gimple.h>
#include <gimple-iterator.h>
#include <gimple-pretty-print.h>
#include <tree-iterator.h>

// Required by GCC plugin API
int plugin_is_GPL_compatible;

// Plugin information
static struct plugin_info const_to_runtime_plugin_info = {
    .version = "1.0",
    .help = "Transforms const objects to runtime-allocated memory.",
};

// Analyze and transform constants
static void transform_constants(void *gcc_data, void *user_data) {
    printf("Running constant-to-runtime transformation.\n");

    for (tree decl = all_decls; decl; decl = TREE_CHAIN(decl)) {
        // Check for constant global variables
        if (TREE_CODE(decl) == VAR_DECL && TREE_READONLY(decl) && DECL_INITIAL(decl)) {
            const char *name = IDENTIFIER_POINTER(DECL_NAME(decl));
            printf("Found const object: %s\n", name);

            // Create malloc call for this object
            tree type = TREE_TYPE(decl);
            size_t size = int_size_in_bytes(type);
            tree malloc_fn = builtin_decl_explicit(BUILT_IN_MALLOC);
            tree size_arg = build_int_cst(integer_type_node, size);
            tree malloc_call = build_call_expr(malloc_fn, 1, size_arg);

            // Replace initializer with malloc result
            DECL_INITIAL(decl) = malloc_call;

            // Generate code to initialize runtime-allocated memory
            tree memcpy_fn = builtin_decl_explicit(BUILT_IN_MEMCPY);
            tree dest = malloc_call;
            tree src = build_address(DECL_INITIAL(decl));
            tree copy_size = build_int_cst(integer_type_node, size);
            tree memcpy_call = build_call_expr(memcpy_fn, 3, dest, src, copy_size);

            printf("Generated runtime allocation for %s.\n", name);
        }
    }
}

// Emit deallocation code at program exit
static void emit_deallocation(void *gcc_data, void *user_data) {
    printf("Adding cleanup code for allocated objects.\n");
    // TODO: Implement tracking and cleanup for allocated objects.
}

// Plugin initialization
int plugin_init(struct plugin_name_args *plugin_info,
                struct plugin_gcc_version *version) {
    // Ensure GCC version compatibility
    if (!plugin_default_version_check(version, &gcc_version)) {
        fprintf(stderr, "Incompatible GCC version.\n");
        return 1;
    }

    // Register callbacks
    printf("Registering GCC plugin callbacks.\n");
    register_callback(plugin_info->base_name, PLUGIN_FINISH_TYPE,
                      transform_constants, NULL);
    register_callback(plugin_info->base_name, PLUGIN_FINISH_UNIT,
                      emit_deallocation, NULL);

    return 0;
}


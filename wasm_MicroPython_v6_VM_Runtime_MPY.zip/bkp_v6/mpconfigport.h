/* This file is part of the MicroPython project, http://micropython.org/
 * The MIT License (MIT)
 * Copyright (c) 2022-2023 Damien P. George
 */

// Include common MicroPython embed configuration.
#include <port/mpconfigport_common.h>

// Use the minimal starting configuration (disables all optional features).
#define MICROPY_CONFIG_ROM_LEVEL                (MICROPY_CONFIG_ROM_LEVEL_MINIMUM)
//#define MICROPY_CONFIG_ROM_LEVEL                (MICROPY_CONFIG_ROM_LEVEL_CORE_FEATURES)

// MicroPython configuration.
#define MICROPY_ENABLE_COMPILER                 (1)
#define MICROPY_ENABLE_GC                       (0)
#define MICROPY_PY_GC                           (0)

#define MICROPY_GCREGS_SETJMP (1)

//#define MICROPY_PY_THREAD (0)
//#define MICROPY_VFS (0)
//#define MICROPY_KBD_EXCEPTION (1)

//#define MICROPY_STACK_CHECK (1)
//#define MICROPY_ENABLE_PYSTACK (1)

//#define MICROPY_USE_INTERNAL_PRINTF (1)
//
//
#define MICROPY_PERSISTENT_CODE_LOAD (1)
#define MICROPY_PY_JSON (1)
#define MICROPY_PY_JSON_SEPARATORS (1)

#define MICROPY_PY_IO (1)
#define MICROPY_PY_IO_IOBASE (0)
#define MICROPY_PY_IO_BYTESIO (0)

#define MICROPY_DEBUG_VERBOSE (0)
#define DEBUG_PRINT (0)
//#define MICROPY_DEBUG_PRINTERS (1)



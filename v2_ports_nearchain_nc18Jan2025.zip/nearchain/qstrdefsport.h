// qstrs specific to this port
// *FORMAT-OFF*
Q(/lib)

#include <emscripten.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>

extern void log_utf8(uint64_t len, uint64_t ptr);
extern void value_return(uint64_t value_len, uint64_t value_ptr);
extern void input(uint64_t register_id);

extern void read_register(uint64_t register_id, uint64_t ptr);
extern uint64_t register_len(uint64_t register_id);
extern void write_register(uint64_t register_id, uint64_t data_len, uint64_t data_ptr);

EMSCRIPTEN_KEEPALIVE
void say_hello() {
    const char *message = "Hello, NEAR from C!. Inside say_hello!";
    uint64_t len = strlen(message);

    // Allocate memory in WASM memory space
    char *wasm_message = (char *)malloc(len + 1);
    strcpy(wasm_message, message);

    uint64_t ptr = (uint64_t)wasm_message;

    // Log the message
    log_utf8(len, ptr);


    value_return(len, ptr);

    free(wasm_message);  // Free memory
}

void hello_world() {
    const char *message = "Hello, NEAR from C!. Inside say_hello!";
    uint64_t len = strlen(message);

    // Allocate memory in WASM memory space
    char *wasm_message = (char *)malloc(len + 1);
    strcpy(wasm_message, message);

    uint64_t ptr = (uint64_t)wasm_message;

    // Log the message
    log_utf8(len, ptr);

    // Allocate memory in WASM memory space
    char *input_message = (char *)malloc(1024);
    uint64_t input_len = 0;
    uint64_t input_ptr = 0;

    input(0);
    input_len = register_len(0);
    read_register(0, (uint64_t) input_message);

    input_ptr = (uint64_t) input_message;

    //value_return(len, ptr);
    value_return(input_len, input_ptr);

    free(wasm_message);  // Free memory
    free(input_message);  // Free memory
}

extern void mp_init();


EMSCRIPTEN_KEEPALIVE
void exec_python() 
{
    // Allocate memory in WASM memory space
    char *input_message = (char *)malloc(1024);
    uint64_t input_len = 0;
    uint64_t input_ptr = 0;
    uint64_t code_ptr = 0;

    input(0);
    input_len = register_len(0);
    read_register(0, (uint64_t) input_message);

    input_ptr = (uint64_t) input_message;

    // Allocate memory in WASM memory space
    char *python_code = (char *)malloc(input_len + 1);
    strncpy(python_code, input_message, input_len);
    python_code[input_len]=0;
    code_ptr = (uint64_t) python_code;
   
    log_utf8(input_len, code_ptr);

    char output[256];
    memset(output, 0, sizeof(output));

    value_return(input_len, code_ptr);

    mp_init();  // Initialize MicroPython
/*

    mp_init();  // Initialize MicroPython

    int result = mp_execute(python_code, output, sizeof(output) - 1);

    if (result == 0) {
        log_utf8(strlen(output), (uint64_t)output);
    } else {
        const char *error = "Error executing Python code.";
        log_utf8(strlen(error), (uint64_t)error);
    }

    mp_deinit();  // Clean up MicroPython
*/
}



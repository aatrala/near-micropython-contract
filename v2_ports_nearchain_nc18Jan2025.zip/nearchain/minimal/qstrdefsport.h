// qstrs specific to this port
// *FORMAT-OFF*

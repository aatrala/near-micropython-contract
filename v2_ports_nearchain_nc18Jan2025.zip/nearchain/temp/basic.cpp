#include <cstdint>
#include <cstring>
#include <string>


// Define the namespace env
namespace env {
    extern "C" void value_return(uint64_t value_len, uint64_t value_ptr); 
/*
    {
        const char* data = reinterpret_cast<const char*>(value_ptr);
        // Normally, this function should interact with NEAR's runtime,
        // but for simplicity, we'll just output the data.
    }
*/

}

extern "C" {
    // Entry point for NEAR
    void hello_near() {
        const char* data = "Hello, NEAR!";
        uint64_t data_len = std::strlen(data);
        uint64_t data_ptr = reinterpret_cast<uint64_t>(data);

        // Call the value_return function in the env namespace
        env::value_return(data_len, data_ptr);
    }
}


#include <emscripten.h>

#include <stdint.h>
//#include <stddef.h>
#include <string.h>
//#include <stdio.h>

#ifndef CUSTOM_CSTDINT
#define CUSTOM_CSTDINT

typedef signed char int8_t;
typedef short int int16_t;
typedef int int32_t;
typedef long long int int64_t;

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long int uint64_t;

#endif // CUSTOM_CSTDINT


//#include "near_env_extern_fun.h"
//extern void env_value_return(uint64_t data_len);
//extern void env_value_return(uint64_t value_len, uint64_t value_ptr);

extern void log_utf8(uint64_t len, uint64_t ptr);
extern void value_return(uint64_t value_len, uint64_t value_ptr);

inline size_t basic_strlen(const char *str) {
        size_t length = 0;
        while (str[length] != '\0') {
            ++length;
        }
        return length;
}


// Exported function for "say_hello" contract method
EMSCRIPTEN_KEEPALIVE
void say_hello() 
{
    uint64_t responseLen=0;
    uint64_t valuePtr = 0;

    const char *message = "Hello, NEAR from C using Emscripten!";
    //near_log(message);
    
    log_utf8(basic_strlen(message), (uint64_t) (message)); 

    // Return a response
    const char response[] = "Success ";
    //size_t response_len = basic_strlen(response);

    responseLen = basic_strlen(response);
    valuePtr = (uint64_t) valuePtr;

    value_return(responseLen, valuePtr);

    return;
}




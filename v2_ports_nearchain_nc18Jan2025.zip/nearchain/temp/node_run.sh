#!/bin/sh
node $(dirname $0)/build/micropython.js "$@"

// qstrs specific to this port
// *FORMAT-OFF*
Q(/lib)
Q(near)
Q(input)
Q(read_register)
Q(register_len)
Q(value_return)
Q(log_utf8)

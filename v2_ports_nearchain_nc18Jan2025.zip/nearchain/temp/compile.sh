#export WASI_SDK_PATH="/home/vboxuser/apps/near-js-contract/near-sample/node-modules/near-sdk-js"
#export DEFS=
#export INCLUDES="-I."
#export SOURCES="basic.c"
#export LIBS=''
#export contractTarget="basic.wasm"

${WASI_SDK_PATH}/bin/clang --sysroot=${WASI_SDK_PATH}/share/wasi-sysroot --target=wasm32-wasi -nostartfiles -Oz -flto -D_GNU_SOURCE -DCONFIG_VERSION="2021-03-27" -DCONFIG_BIGNUM -I. basic.c -Wl,--no-entry -Wl,--allow-undefined -Wl,-z,stack-size=${256 * 1024} -Wl,--lto-O3 -o basic.wasm


#ifndef CUSTOM_CSTDINT
#define CUSTOM_CSTDINT

typedef signed char int8_t;
typedef short int int16_t;
typedef int int32_t;
typedef long long int int64_t;

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long int uint64_t;

#endif // CUSTOM_CSTDINT

#ifndef CUSTOM_CSTRING
#define CUSTOM_CSTRING

#include <stddef.h>

namespace std {
    inline size_t strlen(const char* str) {
        size_t length = 0;
        while (str[length] != '\0') {
            ++length;
        }
        return length;
    }

    inline void strcpy(char* dest, const char* src) {
        while (*src) {
            *dest++ = *src++;
        }
        *dest = '\0';
    }

    class string {
    public:
        string(const char* str) {
            len = strlen(str);
            data = new char[len + 1];
            strcpy(data, str);
        }

        ~string() {
            delete[] data;
        }

        size_t length() const {
            return len;
        }

        const char* c_str() const {
            return data;
        }

    private:
        char* data;
        size_t len;
    };
}


#endif // CUSTOM_CSTRING



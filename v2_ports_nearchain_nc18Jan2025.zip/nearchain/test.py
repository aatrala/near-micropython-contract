def hello_world():
   return "hello, world"; 

print (hello_world());

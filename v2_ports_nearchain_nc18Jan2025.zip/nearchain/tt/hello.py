help('modules')
def sum(a, b):
 return a + b

print ("Hello, world");
print ("sum is ", sum(20, 30));

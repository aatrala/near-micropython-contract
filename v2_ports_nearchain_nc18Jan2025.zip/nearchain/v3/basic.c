#include <emscripten.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>

extern void log_utf8(uint64_t len, uint64_t ptr);
extern void value_return(uint64_t value_len, uint64_t value_ptr);

EMSCRIPTEN_KEEPALIVE
void say_hello() {
    const char *message = "Hello, NEAR from C!";
    uint64_t len = strlen(message);

    // Allocate memory in WASM memory space
    char *wasm_message = (char *)malloc(len + 1);
    strcpy(wasm_message, message);

    uint64_t ptr = (uint64_t)wasm_message;

    // Log the message
    log_utf8(len, ptr);

    free(wasm_message);  // Free memory
}

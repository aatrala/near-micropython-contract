emcc basic.c -o basic.wasm -s EXPORTED_FUNCTIONS='["_say_hello", "_hello_world"]' --no-entry -s WASM_BIGINT -Oz -s STANDALONE_WASM -s ERROR_ON_UNDEFINED_SYMBOLS=0 -s ALLOW_MEMORY_GROWTH=0


near deploy aatralarasu.testnet basic.wasm
near call --use-account aatralarasu.testnet aatralarasu.testnet hello_world '{"name":"Hello from Frol & Aatral"}'


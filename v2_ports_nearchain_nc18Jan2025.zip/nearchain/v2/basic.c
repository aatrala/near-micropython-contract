#include <emscripten.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

//#include "near_env_extern_fun.h"

extern void log_utf8(uint64_t len, uint64_t ptr);
extern void value_return(uint64_t value_len, uint64_t value_ptr);

static const char *message = "Hello, NEAR from C!";
static const char *response = "Success";

// Function to call log_utf8 with a string
void call_log_utf8() {
    uint64_t len = strlen(message);  // Get the length of the string
    uint64_t ptr = (uint64_t)message;  // Cast the string pointer to uint64_t

    log_utf8(len, ptr);  // Call log_utf8
}


// Exported function for "say_hello" contract method
EMSCRIPTEN_KEEPALIVE
void say_hello() 
{
    uint64_t responseLen=0;
    uint64_t valuePtr = 0;

    char *logMessage ;

    uint64_t msgLen = 0;

    call_log_utf8();

}

    //uint64_t msgPtr = 0;
    //msgPtr = (uint64_t) message;
    
    //msgLen = strlen(message);
    //logMessage = malloc(msgLen+1);



    //log_utf8(5, (uint64_t) "hello"); 

    // Return a response
    //responseLen = strlen(response);
    //valuePtr = (uint64_t) response;

    //value_return(responseLen, (uint64_t) response);




#include <emscripten.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>

//#include "near_env_extern_fun.h"

extern void log_utf8(uint64_t len, uint64_t ptr);
extern void value_return(uint64_t value_len, uint64_t value_ptr);

// Exported function for "say_hello" contract method
EMSCRIPTEN_KEEPALIVE
void say_hello() 
{
    const char *message = "Hello, NEAR from C!                                                                                                                                                                                                              ";
    const char *response = "Success                                                                                                                                                                                                                    ";

    uint64_t responseLen=0;
    uint64_t valuePtr = 0;

    //uint64_t msgLen = 0;
    //uint64_t msgPtr = 0;
    
    //msgLen = strlen(message);
    //msgPtr = (uint64_t) message;

    //log_utf8(8, (uint64_t) message); 

    // Return a response
    //responseLen = strlen(response);
    //valuePtr = (uint64_t) response;

    //value_return(responseLen, (uint64_t) response);

}




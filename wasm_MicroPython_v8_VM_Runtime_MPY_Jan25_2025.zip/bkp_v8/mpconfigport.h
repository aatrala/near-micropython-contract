/* BEGIN OF FILE: mpconfigport.h */

// Include common MicroPython embed configuration.
#include <port/mpconfigport_common.h>

// Use the minimal starting configuration (disables all optional features).
#define MICROPY_CONFIG_ROM_LEVEL                (MICROPY_CONFIG_ROM_LEVEL_MINIMUM)
//#define MICROPY_CONFIG_ROM_LEVEL                (MICROPY_CONFIG_ROM_LEVEL_CORE_FEATURES)

// MicroPython configuration.
#define MICROPY_ENABLE_COMPILER                 (1)
#define MICROPY_ENABLE_GC                       (0)
#define MICROPY_PY_GC                           (0)

#define MICROPY_GCREGS_SETJMP (1)

//#define MICROPY_PY_THREAD (0)
//#define MICROPY_VFS (0)
//#define MICROPY_KBD_EXCEPTION (1)

//#define MICROPY_STACK_CHECK (1)
//#define MICROPY_ENABLE_PYSTACK (1)

//#define MICROPY_USE_INTERNAL_PRINTF (1)
//
//
#define MICROPY_PERSISTENT_CODE_LOAD (1)
#define MICROPY_PY_JSON (1)
#define MICROPY_PY_JSON_SEPARATORS (1)

#define MICROPY_PY_IO (1)
#define MICROPY_PY_IO_IOBASE (0)
#define MICROPY_PY_IO_BYTESIO (0)

#define MICROPY_DEBUG_VERBOSE (0)
#define DEBUG_PRINT (0)
//#define MICROPY_DEBUG_PRINTERS (1)
//

/* each of the global variable is converted to pointers and memory allocation based */


#define MICROPY_WASM_OBJECT_ORIENTED (1)
#define MICROPY_WASM_ERROR_HANDLING (0)

#if 1

#define MICROPY_WASM_OBJECT_MP_TYPE_MODULE (1)
#define MICROPY_WASM_OBJECT_MP_TYPE_BUILTINS (1)
#define MICROPY_WASM_OBJECT_MP_TYPE_JSON (1)
#define MICROPY_WASM_OBJECT_MP_TYPE_IO (1)
#define MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_TABLE (1)
#define MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_MAP (1)

// v8 onwards constant_pool, mp_type_dict
#define MICROPY_WASM_OBJECT_CONSTANT_POOL (1)
#define MICROPY_WASM_OBJECT_MP_TYPE_DICT (1)

#endif

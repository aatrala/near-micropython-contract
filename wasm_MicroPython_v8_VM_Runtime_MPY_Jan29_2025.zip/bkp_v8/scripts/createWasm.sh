# Create a wasm file that will be deployed in near 
# Use > near deploy aatralarasu.testnet build/v8.wasm
# Use > near call to call the exec_python with the json argument

emcc   -Ilibmicropython 		\
	libmicropython/embed_util.c 	\
	libmicropython/mphalport.c 	\
	libmicropython/micropython.c 	\
	src/v8.c 			\
	-o build/v8.wasm -s EXPORTED_FUNCTIONS='["_say_hello", "_hello_world", "_exec_python"]' \
	--no-entry -s WASM_BIGINT -s ALLOW_MEMORY_GROWTH=0 					\
	-DMICROPY_WASM_LIBRARY -fdata-sections -ffunction-sections 				\
	--target=wasm32-unknown-emscripten -s ERROR_ON_UNDEFINED_SYMBOLS=0 			\
	-s STANDALONE_WASM 
#-Oz 
#-Oz 
#-gsource-map 
#-finline-functions 
#-Oz --profiling-funcs 

#-s ASSERTIONS=2  

# near commands to deploy and call methods
# deploy to near testnet
#$> near deploy aatralarasu.testnet build/v8.wasm

# call the method in smartcontract with sample json argument
#$> near call --use-account aatralarasu.testnet aatralarasu.testnet exec_python '{"name":"Hello for Python-gig"}'


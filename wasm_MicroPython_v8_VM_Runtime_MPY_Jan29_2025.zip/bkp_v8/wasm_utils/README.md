
mpy_to_binary_string.c 
-> takes the input testing.mpy file and outputs the binary string array that can be
integrated to v8.c file

Use mpy-cross folder to generate the mpy file from python file in main micropython/mpy-cross folder

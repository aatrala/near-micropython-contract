//#include <emscripten.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

extern void log_utf8(uint64_t len, uint64_t ptr);
extern void value_return(uint64_t value_len, uint64_t value_ptr);
extern void input(uint64_t register_id);

extern void read_register(uint64_t register_id, uint64_t ptr);
extern uint64_t register_len(uint64_t register_id);
extern void write_register(uint64_t register_id, uint64_t data_len, uint64_t data_ptr);


//---EMSCRIPTEN_KEEPALIVE
__attribute__((export_name("say_hello")))
void say_hello() {
    const char *message = "Hello, NEAR from C!. Inside say_hello!";
    uint64_t len = strlen(message);

    // Allocate memory in WASM memory space
    char *wasm_message = (char *)malloc(len + 1);
    strcpy(wasm_message, message);

    uint64_t ptr = (uint64_t)wasm_message;

    // Log the message
    log_utf8(len, ptr);


    value_return(len, ptr);

    free(wasm_message);  // Free memory
}

__attribute__((export_name("hello_world")))
void hello_world() {
    const char *message = "Hello, NEAR from C!. Inside say_hello!";
    uint64_t len = strlen(message);

    // Allocate memory in WASM memory space
    char *wasm_message = (char *)malloc(len + 1);
    strcpy(wasm_message, message);

    uint64_t ptr = (uint64_t)wasm_message;

    // Log the message
    log_utf8(len, ptr);

    // Allocate memory in WASM memory space
    char *input_message = (char *)malloc(1024);
    uint64_t input_len = 0;
    uint64_t input_ptr = 0;

    input(0);
    input_len = register_len(0);
    read_register(0, (uint64_t) input_message);

    input_ptr = (uint64_t) input_message;

    //value_return(len, ptr);
    value_return(input_len, input_ptr);

    free(wasm_message);  // Free memory
    free(input_message);  // Free memory
}

#include "py/micropython.h"
#include "port/micropython_embed.h"

void near_log_messageN(const char *msg, size_t len) 
{
    uint64_t msg_len = 0;
    uint64_t msg_ptr = 0;

    msg_len = len;
    msg_ptr = (uint64_t) msg;

    log_utf8(msg_len, msg_ptr);
}


void near_log_message(const char *msg) 
{
    uint64_t msg_len = 0;
    uint64_t msg_ptr = 0;

    msg_len = strlen(msg);
    msg_ptr = (uint64_t) msg;

    log_utf8(msg_len, msg_ptr);
}

//EMSCRIPTEN_KEEPALIVE
__attribute__((export_name("interpret_python")))
void interpret_python() 
{
    // This is example 1 script, which will be compiled and executed.
    static const char *example_1 =
    "\n"
    "a=42; b=240; c=a+b; \n"
    "print('\\n');"
    "print(a, b, c);\n"
    "\n"
    "print('hello world!', list(x + 1 for x in range(10)), end='eol\\n')";

     // This is example 2 script, which will be compiled and executed.
     static const char *example_2 =
     "for i in range(10):\n"
     "    print('iter {:08}'.format(i))\n"
     "\n"
     "try:\n"
     "    1//1\n"
     "except Exception as er:\n"
     "    print('caught exception', repr(er))\n"
     "\n"
     "import gc\n"
     "print('run GC collect')\n"
     "gc.collect()\n"
     "\n"
     "print('finish')\n"
     ;


    char global_wasm_heap[8 * 1024];
    int  global_wasm_stack_top = 0;

    // Allocate memory in WASM memory space
    char *input_message = (char *)malloc(1024);
    uint64_t input_len = 0;
    uint64_t input_ptr = 0;
    uint64_t code_ptr = 0;

    input(0);
    input_len = register_len(0);
    read_register(0, (uint64_t) input_message);

    input_ptr = (uint64_t) input_message;

    // Allocate memory in WASM memory space
    char *python_code = (char *)malloc(input_len + 1);
    strncpy(python_code, input_message, input_len);
    python_code[input_len]=0;
    code_ptr = (uint64_t) python_code;
   
    log_utf8(input_len, code_ptr);

    char output[256];
    memset(output, 0, sizeof(output));

    value_return(input_len, code_ptr);

    near_log_message("initialising python interpreter");

#if 0
    mp_embed_init(&global_wasm_heap[0], sizeof(global_wasm_heap), &global_wasm_stack_top);

    mp_embed_exec_str(python_code);
    mp_embed_exec_str(example_1);
    mp_embed_exec_str(example_2);

#if 0
    //int result = mp_execute(python_code, output, sizeof(output) - 1);

    if (result == 0) {
        log_utf8(strlen(output), (uint64_t)output);
    } else {
        const char *error = "Error executing Python code.";
        log_utf8(strlen(error), (uint64_t)error);
    }
#endif

    mp_embed_deinit();  // Clean up MicroPython
#endif

}

#ifdef MICROPY_PY_IO
mp_obj_t mp_builtin_open(size_t n_args, const mp_obj_t *args, mp_map_t *kwargs) 
{
    return mp_const_none;
}
MP_DEFINE_CONST_FUN_OBJ_KW(mp_builtin_open_obj, 1, mp_builtin_open);
#endif

const char *global_ptr = "interesting message";


//EMSCRIPTEN_KEEPALIVE
__attribute__((export_name("exec_python")))
void exec_python() 
{

    static const uint8_t hardcoded_bytecode[] = 
	{
	0x4D , 0x06 , 0x00 , 0x1F , 0x0E , 0x03 , 0x14 , 0x74 , 0x65 , 0x73 , 0x74 , 0x69 , 0x6E , 0x67 , 0x2E , 0x70 , 
	0x79 , 0x00 , 0x0F , 0x08 , 0x6A , 0x73 , 0x6F , 0x6E , 0x00 , 0x0E , 0x57 , 0x65 , 0x6C , 0x63 , 0x6F , 0x6D , 
	0x65 , 0x00 , 0x04 , 0x74 , 0x6F , 0x00 , 0x0A , 0x47 , 0x65 , 0x65 , 0x6B , 0x73 , 0x00 , 0x06 , 0x66 , 0x6F , 
	0x72 , 0x00 , 0x0A , 0x64 , 0x75 , 0x6D , 0x70 , 0x73 , 0x00 , 0x82 , 0x33 , 0x81 , 0x77 , 0x14 , 0x44 , 0x69 , 
	0x63 , 0x74 , 0x69 , 0x6F , 0x6E , 0x61 , 0x72 , 0x79 , 0x00 , 0x12 , 0x61 , 0x61 , 0x5F , 0x73 , 0x74 , 0x72 , 
	0x69 , 0x6E , 0x67 , 0x00 , 0x02 , 0x61 , 0x00 , 0x02 , 0x62 , 0x00 , 0x05 , 0x1B , 0x6E , 0x65 , 0x61 , 0x72 , 
	0x20 , 0x6A , 0x73 , 0x6F , 0x6E , 0x20 , 0x74 , 0x65 , 0x73 , 0x74 , 0x20 , 0x70 , 0x72 , 0x6F , 0x67 , 0x72 , 
	0x61 , 0x6D , 0x20 , 0x76 , 0x31 , 0x2E , 0x30 , 0x00 , 0x05 , 0x23 , 0x45 , 0x71 , 0x75 , 0x69 , 0x76 , 0x61 , 
	0x6C , 0x65 , 0x6E , 0x74 , 0x20 , 0x61 , 0x61 , 0x20 , 0x73 , 0x74 , 0x72 , 0x69 , 0x6E , 0x67 , 0x20 , 0x6F , 
	0x66 , 0x20 , 0x64 , 0x69 , 0x63 , 0x74 , 0x69 , 0x6F , 0x6E , 0x61 , 0x72 , 0x79 , 0x3A , 0x00 , 0x05 , 0x33 , 
	0x53 , 0x75 , 0x6D , 0x20 , 0x6F , 0x66 , 0x20 , 0x74 , 0x77 , 0x6F , 0x20 , 0x6E , 0x75 , 0x6D , 0x62 , 0x65 , 
	0x72 , 0x73 , 0x20 , 0x32 , 0x35 , 0x20 , 0x61 , 0x6E , 0x64 , 0x20 , 0x35 , 0x35 , 0x20 , 0x61 , 0x66 , 0x74 , 
	0x65 , 0x72 , 0x20 , 0x63 , 0x61 , 0x6C , 0x6C , 0x69 , 0x6E , 0x67 , 0x20 , 0x73 , 0x75 , 0x6D , 0x20 , 0x69 , 
	0x73 , 0x20 , 0x3A , 0x00 , 0x85 , 0x44 , 0x20 , 0x14 , 0x01 , 0x46 , 0x47 , 0x78 , 0x60 , 0x40 , 0x6A , 0x20 , 
	0x49 , 0x64 , 0x80 , 0x51 , 0x1B , 0x02 , 0x16 , 0x02 , 0x11 , 0x09 , 0x23 , 0x00 , 0x34 , 0x01 , 0x59 , 0x2C , 
	0x05 , 0x10 , 0x03 , 0x81 , 0x62 , 0x10 , 0x04 , 0x82 , 0x62 , 0x10 , 0x05 , 0x83 , 0x62 , 0x10 , 0x06 , 0x84 , 
	0x62 , 0x10 , 0x05 , 0x85 , 0x62 , 0x16 , 0x0A , 0x11 , 0x02 , 0x14 , 0x07 , 0x11 , 0x0A , 0x36 , 0x01 , 0x16 , 
	0x0B , 0x11 , 0x09 , 0x23 , 0x01 , 0x11 , 0x0B , 0x34 , 0x02 , 0x59 , 0x32 , 0x00 , 0x16 , 0x08 , 0x11 , 0x09 , 
	0x23 , 0x02 , 0x11 , 0x08 , 0x99 , 0x22 , 0x37 , 0x34 , 0x02 , 0x34 , 0x02 , 0x59 , 0x51 , 0x63 , 0x01 , 0x58 , 
	0x1A , 0x0A , 0x08 , 0x0C , 0x0D , 0x80 , 0x13 , 0xB0 , 0xB1 , 0xF2 , 0x63 , 
	 };

    char global_wasm_heap[128 * 1024];
    int  global_wasm_stack_top = 0;

    // Allocate memory in WASM memory space
    char *input_message = (char *)malloc(1024);
    uint64_t input_len = 0;
    uint64_t input_ptr = 0;
    uint64_t code_ptr = 0;

    input(0);
    input_len = register_len(0);
    read_register(0, (uint64_t) input_message);

    input_ptr = (uint64_t) input_message;

    // Allocate memory in WASM memory space
    char *python_code = (char *)malloc(input_len + 1);
    strncpy(python_code, input_message, input_len);
    python_code[input_len]=0;
    code_ptr = (uint64_t) python_code;
   
    log_utf8(input_len, code_ptr);

    char output[256];
    memset(output, 0, sizeof(output));

    value_return(input_len, code_ptr);

    near_log_message("initialising python interpreter");

    near_log_message(global_ptr);
    global_ptr = python_code;

    near_log_message("initialised global pointer");

    mp_embed_init(&global_wasm_heap[0], sizeof(global_wasm_heap), &global_wasm_stack_top);

    mp_embed_exec_mpy(hardcoded_bytecode, sizeof(hardcoded_bytecode));

    // Deinitialise MicroPython.
    mp_embed_deinit();

#if 0
    mp_embed_init(&global_wasm_heap[0], sizeof(global_wasm_heap), &global_wasm_stack_top);

    mp_embed_exec_str(python_code);
    mp_embed_exec_str(example_1);
    mp_embed_exec_str(example_2);

#if 0
    //int result = mp_execute(python_code, output, sizeof(output) - 1);

    if (result == 0) {
        log_utf8(strlen(output), (uint64_t)output);
    } else {
        const char *error = "Error executing Python code.";
        log_utf8(strlen(error), (uint64_t)error);
    }
#endif

    mp_embed_deinit();  // Clean up MicroPython
#endif

}




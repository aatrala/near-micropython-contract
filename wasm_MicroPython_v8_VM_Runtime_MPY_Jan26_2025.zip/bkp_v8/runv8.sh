emcc -I. -Imicropython_embed -Imicropython_embed/port micropython_embed/port/embed_util.c micropython_embed/port/mphalport.c micropython_embed/py/micropython.c micropython_embed/py/printf.c v8.c -o v8.wasm -s EXPORTED_FUNCTIONS='["_say_hello", "_hello_world", "_exec_python"]' --no-entry -s WASM_BIGINT -s STANDALONE_WASM -s ALLOW_MEMORY_GROWTH=0 -DMICROPY_WASM_LIBRARY -Oz -fdata-sections -ffunction-sections -finline-functions --target=wasm32-unknown-emscripten -s ERROR_ON_UNDEFINED_SYMBOLS=0 

#-s ASSERTIONS=2  



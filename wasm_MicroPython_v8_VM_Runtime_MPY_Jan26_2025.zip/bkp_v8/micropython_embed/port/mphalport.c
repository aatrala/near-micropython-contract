/* BEGIN OF FILE: mphalport.c */

#include <stdio.h>

#ifdef MICROPY_WASM_LIBRARY
extern void near_log_message(const char *msg);
extern void near_log_messageN(const char *msg, size_t len);
#endif

// Send string of given length to stdout, converting \n to \r\n.
void mp_hal_stdout_tx_strn_cooked(const char *str, size_t len) 
{
#ifdef MICROPY_WASM_LIBRARY
    near_log_messageN(str, len);
#else
    printf("%.*s", (int)len, str);
#endif
}

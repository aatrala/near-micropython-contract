#include <stdint.h>
#include <string.h>
#include <stdio.h>

// Declare the log_utf8 function that will be imported from JavaScript
extern void log_utf8(uint64_t len, uint64_t ptr);

void send_message_to_js() {
    const char *message = "Hello from WebAssembly!";
    uint64_t message_len = strlen(message);

    // Print the message to console (for debugging)
    printf("Sending message: '%s' with length: %llu\n", message, message_len);

    // Call the imported log_utf8 function to pass the message to JavaScript
    log_utf8(message_len, (uint64_t)message);
}

int main() {
    // Call the function to send the message
    send_message_to_js();
    return 0;
}


const env = {
  memory: new WebAssembly.Memory({ initial: 1 }),

  // Log the UTF-8 string passed from WebAssembly
  log_utf8: (len, ptr) => {
    console.log(`[log_utf8] len=${len}, ptr=${ptr}`);

    // Convert BigInt to Number for memory access
    const length = Number(len);
    const pointer = Number(ptr);

    // Access the WebAssembly memory buffer
    const memoryBuffer = new Uint8Array(env.memory.buffer);

    // Extract the raw bytes from the memory buffer
    const rawBytes = memoryBuffer.slice(pointer, pointer + length);
    console.log('[log_utf8] Raw memory bytes:', rawBytes);

    // Decode the message from bytes and log it
    const message = new TextDecoder().decode(rawBytes);
    console.log(`[log_utf8] Message from WASM: "${message}"`);
  },
};

fetch('wasm_example.wasm')
  .then(response => response.arrayBuffer())
  .then(bytes => {
    return WebAssembly.instantiate(bytes, { env });
  })
  .then(result => {
    console.log('WASM module loaded successfully.');
    
    // Call the send_message_to_js function from WebAssembly
    const { send_message_to_js } = result.instance.exports;
    send_message_to_js(); // This will trigger log_utf8 in JavaScript
  })
  .catch((error) => {
    console.error('Error loading WebAssembly module:', error);
  });


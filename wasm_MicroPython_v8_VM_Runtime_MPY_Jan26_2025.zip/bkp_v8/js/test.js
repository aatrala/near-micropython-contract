const fs = require('fs');
const path = require('path');

// Define the required host functions for the `env` module
const env = {
  memory: new WebAssembly.Memory({ initial: 2048 }), // Ensure memory is available
	log_utf8: (len, ptr) => {
    console.log(`[log_utf8] len=${len}, ptr=${ptr}`);

    // Convert BigInt to Number for memory access
    const length = Number(len);
    const pointer = Number(ptr);

    const memoryBuffer = new Uint8Array(env.memory.buffer);

    // Check if pointer and length are valid
    if (pointer + length > memoryBuffer.length) {
      console.error(`[log_utf8] Invalid memory access. Pointer + length exceeds memory size.`);
      return;
    }

    // Log the raw memory bytes from the given pointer
    const rawBytes = memoryBuffer.slice(pointer, pointer + length);
    console.log('[log_utf8] Raw memory bytes:', rawBytes);

    // Try to decode the message (if it's a valid UTF-8 string)
    const message = new TextDecoder().decode(rawBytes);
    console.log(`[log_utf8] Message from WASM: "${message}"`);
  },

  read_register: (register_id, ptr) => {
    console.log(`[read_register] register_id=${register_id}, ptr=${ptr}`);

    // Simulated message or data
    const message = "Hello from JavaScript!";
    const messageBuffer = new TextEncoder().encode(message);

    // Access the WebAssembly memory buffer
    const memoryBuffer = new Uint8Array(env.memory.buffer);

    // Write the message to the memory at the given pointer
    for (let i = 0; i < messageBuffer.length; i++) {
      memoryBuffer[ptr + i] = messageBuffer[i];
    }

    console.log(`[read_register] Message written to memory: "${message}"`);
  },
  old_log_utf8: (len, ptr) => {
    console.log(`[log_utf8] len=${len}, ptr=${ptr}`);
    // Placeholder implementation for logging
  },
  value_return: (value_len, value_ptr) => {
    console.log(`[value_return] value_len=${value_len}, value_ptr=${value_ptr}`);
    // Placeholder for returning values
  },
  input: (register_id) => {
    console.log(`[input] register_id=${register_id}`);
    // Placeholder for input simulation
  },
  old_read_register: (register_id, ptr) => {
    console.log(`[read_register] register_id=${register_id}, ptr=${ptr}`);

    // Placeholder for reading a register
  },
  register_len: (register_id) => {
    console.log(`[register_len] register_id=${register_id}`);
    return 0n; // Simulated register length
  },
  write_register: (register_id, data_len, data_ptr) => {
    console.log(
      `[write_register] register_id=${register_id}, data_len=${data_len}, data_ptr=${data_ptr}`
    );
    // Placeholder for writing to a register
  },
};

// Path to the WebAssembly file
const wasmFilePath = path.resolve(__dirname, 'v8.wasm');

// Load and instantiate the WebAssembly module
fs.readFile(wasmFilePath, (err, data) => {
  if (err) {
    console.error(`Failed to read the WASM file: ${err.message}`);
    return;
  }

  WebAssembly.instantiate(data, { env })
    .then((result) => {
      console.log('WASM module loaded successfully.');
      console.log('Available exports:', result.instance.exports);

      // Example: Call an exported function
      if (result.instance.exports.exec_python) {
        const exec_python = result.instance.exports.exec_python;
        console.log('Calling exec_python:', exec_python());
      } else {
        console.warn('Function exec_python is not exported by the module.');
      }
    })
    .catch((e) => {
      console.error('Failed to instantiate the WASM module:', e);
    });
});


/* BEGIN OF FILE: embed_util.c */

#ifdef MICROPY_WASM_LIBRARY_CLANG
#include <string.h>
#else
#include <string.h>
#endif

#include "micropython_embed.h"
#include "micropython.h"

#if WASM_ENV_O3
// Initialise the runtime.
void mp_embed_init(wasm_env_t *my_env, void *gc_heap, size_t gc_heap_size, void *stack_top) 
#else
// Initialise the runtime.
void mp_embed_init(void *gc_heap, size_t gc_heap_size, void *stack_top) 
#endif
{

#ifdef MICROPY_WASM_LIBRARY
    near_log_message("Inside mp_embed_init\n");
#endif

#if MICROPY_WASM_OBJECT_ORIENTED

#if MICROPY_WASM_OBJECT_MP_TYPE_MODULE
#if WASM_ENV_O3
    global_init_const_mp_type_module(my_env);
#else
    global_init_const_mp_type_module();
#endif
#endif

#ifdef MICROPY_WASM_LIBRARY
    near_log_message("after mp_type_module\n");
#endif

#if MICROPY_WASM_OO 

    //global_init_mp_state_ctx();
    //global_init_mp_module_main();

#else
#if WASM_ENV_O3
    global_init_mp_state_ctx(my_env);
    global_init_mp_module_main(my_env);
#else
    global_init_mp_state_ctx();
    global_init_mp_module_main();
#endif
#endif

#if MICROPY_WASM_OBJECT_MP_TYPE_IO 
#if WASM_ENV_O3
    global_init_const_mp_module_io(my_env);
#else
    global_init_const_mp_module_io();
#endif
#endif

#if MICROPY_WASM_OBJECT_MP_TYPE_JSON 
#if WASM_ENV_O3
    global_init_const_mp_module_json(my_env);
#else
    global_init_const_mp_module_json();
#endif
#endif

#if MICROPY_WASM_OBJECT_MP_TYPE_BUILTINS 
#if WASM_ENV_O3
    global_init_const_mp_module_builtins(my_env);
#else
    global_init_const_mp_module_builtins();
#endif
#endif


#if MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_TABLE  
#if WASM_ENV_O3
    global_init_const_mp_builtin_module_table(my_env);
#else
    global_init_const_mp_builtin_module_table();
#endif
#endif

#if MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_MAP
#if WASM_ENV_O3
    global_init_const_mp_builtin_module_map(my_env);
#else
    global_init_const_mp_builtin_module_map();
#endif
#endif


#endif

#ifdef MICROPY_WASM_LIBRARY
    near_log_message("Before mp_stack_set_top\n");
#endif

#if MICROPY_WASM_OO 
#else

#if WASM_ENV_O3
    mp_stack_set_top(my_env, stack_top);
#else
    mp_stack_set_top(stack_top);
#endif
#endif

#if MICROPY_WASM_LIBRARY
    near_log_message("before gc_init");
#endif    

#if MICROPY_ENABLE_GC
    //gc_init(gc_heap, (uint8_t *)gc_heap + gc_heap_size);
#endif

#if MICROPY_WASM_LIBRARY
    near_log_message("before mp_init");
#endif

#if MICROPY_WASM_LIBRARY
    near_log_message("before mp_init");
#if WASM_ENV_O3
    mp_init(my_env);
#else
    mp_init();
#endif

#else

#if WASM_ENV_O3
    mp_init(my_env);
#else
    mp_init();
#endif

#endif

#ifdef MICROPY_WASM_LIBRARY
    near_log_message("Before init_mp_module_main\n");
#endif

#if MICROPY_WASM_OO 

#if WASM_ENV_O3
    global_init_mp_module_main(my_env);
#else
    //global_init_mp_state_ctx();
    
    global_init_mp_module_main();
#endif

#endif
    
    
}

#if MICROPY_ENABLE_COMPILER
// Compile and execute the given source script (Python text).

#if WASM_ENV_O3
void mp_embed_exec_str(wasm_env_t *my_env, const char *src) {
#else
void mp_embed_exec_str(const char *src) {
#endif
    nlr_buf_t nlr;
    if (nlr_push(&nlr) == 0) {
        // Compile, parse and execute the given string.
        mp_lexer_t *lex = mp_lexer_new_from_str_len(MP_QSTR__lt_stdin_gt_, src, strlen(src), 0);
        qstr source_name = lex->source_name;
        mp_parse_tree_t parse_tree = mp_parse(lex, MP_PARSE_FILE_INPUT);
        mp_obj_t module_fun = mp_compile(&parse_tree, source_name, true);
        mp_call_function_0(module_fun);
        nlr_pop();
    } else {
        // Uncaught exception: print it out.
        mp_obj_print_exception(&mp_plat_print, (mp_obj_t)nlr.ret_val);
    }
}
#endif

//#if MICROPY_PERSISTENT_CODE_LOAD

#if WASM_ENV_O3 || WASM_ENV_O4
void mp_embed_exec_mpy(wasm_env_t *my_env, const uint8_t *mpy, size_t len) 
#else
void mp_embed_exec_mpy(const uint8_t *mpy, size_t len) 
#endif
{
    nlr_buf_t nlr;
#if WASM_ENV_O3
    //if (nlr_push(my_env, &nlr) == 0) {
    if (nlr_push(&nlr) == 0) {
#else
    if (nlr_push(&nlr) == 0) {
#endif
        // Execute the given .mpy data.
        mp_module_context_t *ctx = m_new_obj(mp_module_context_t);

#if WASM_ENV_O4
	ctx->my_env = my_env;
#endif

#if WASM_ENV_O3
        ctx->module.globals = mp_globals_get(my_env);
#else
        ctx->module.globals = mp_globals_get();
#endif

        mp_compiled_module_t cm;
        cm.context = ctx;
        mp_raw_code_load_mem(mpy, len, &cm);
        mp_obj_t f = mp_make_function_from_proto_fun(cm.rc, ctx, MP_OBJ_NULL);
        mp_call_function_0(f);
        nlr_pop();
    } else {
        // Uncaught exception: print it out.
        mp_obj_print_exception(&mp_plat_print, (mp_obj_t)nlr.ret_val);
    }
}
//#endif

#if WASM_ENV_O3
// Deinitialise the runtime.
void mp_embed_deinit(wasm_env_t *my_env) {
#else
// Deinitialise the runtime.
void mp_embed_deinit(void) {
#endif

#if MICROPY_WASM_OBJECT_ORIENTED

#if MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_MAP
#if WASM_ENV_O3
    global_deinit_const_mp_builtin_module_map(my_env);
#else
    global_deinit_const_mp_builtin_module_map();
#endif
#endif

#if MICROPY_WASM_OBJECT_MP_TYPE_BUILTIN_MODULE_TABLE  
#if WASM_ENV_O3
    global_deinit_const_mp_builtin_module_table(my_env);
#else
    global_deinit_const_mp_builtin_module_table();
#endif
#endif

#if MICROPY_WASM_OBJECT_MP_TYPE_BUILTINS 

#if WASM_ENV_O3
    global_deinit_const_mp_module_builtins(my_env);
#else
    global_deinit_const_mp_module_builtins();
#endif
#endif

#if MICROPY_WASM_OBJECT_MP_TYPE_MODULE

#if WASM_ENV_O3
    global_deinit_const_mp_type_module(my_env);
#else
    global_deinit_const_mp_type_module();
#endif

#endif


#if MICROPY_WASM_OBJECT_MP_TYPE_JSON 
#if WASM_ENV_O3
    global_deinit_const_mp_module_json(my_env);
#else
    global_deinit_const_mp_module_json();
#endif
#endif

#if MICROPY_WASM_OBJECT_MP_TYPE_IO 
#if WASM_ENV_O3
    global_deinit_const_mp_module_io(my_env);
#else
    global_deinit_const_mp_module_io();
#endif
#endif

#if MICROPY_WASM_OO 
#else
    
#if WASM_ENV_O3
    global_deinit_mp_state_ctx(my_env);
    global_deinit_mp_module_main(my_env);
#else
    global_deinit_mp_state_ctx();
    global_deinit_mp_module_main();
#endif
#endif
#endif

#if WASM_ENV_O3
    mp_deinit(my_env);
#else
    mp_deinit();
#endif

}

#if MICROPY_ENABLE_GC
// Run a garbage collection cycle.
void gc_collect(void) {
    gc_collect_start();
    gc_helper_collect_regs_and_stack();
    gc_collect_end();
}
#endif

// Called if an exception is raised outside all C exception-catching handlers.
void nlr_jump_fail(void *val) {
    for (;;) {
    }
}

#ifndef NDEBUG
// Used when debugging is enabled.
void __assert_func(const char *file, int line, const char *func, const char *expr) {
    for (;;) {
    }
}
#endif
/* END OF FILE: embed_util.c */

/* BEGINE OF FILE: micropython_embed.h */
#ifndef MICROPY_INCLUDED_MICROPYTHON_EMBED_H
#define MICROPY_INCLUDED_MICROPYTHON_EMBED_H

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#include "micropython.h"

#if WASM_ENV_O3

void mp_embed_init(wasm_env_t *my_env, void *gc_heap, size_t gc_heap_size, void *stack_top);
void mp_embed_deinit(wasm_env_t *my_env);

// Only available if MICROPY_ENABLE_COMPILER is enabled.
void mp_embed_exec_str(wasm_env_t *my_env, const char *src);

// Only available if MICROPY_PERSISTENT_CODE_LOAD is enabled.
void mp_embed_exec_mpy(wasm_env_t *my_env, const uint8_t *mpy, size_t len);


#else

void mp_embed_init(void *gc_heap, size_t gc_heap_size, void *stack_top);
void mp_embed_deinit(void);

// Only available if MICROPY_ENABLE_COMPILER is enabled.
void mp_embed_exec_str(const char *src);

#if WASM_ENV_O4
// Only available if MICROPY_PERSISTENT_CODE_LOAD is enabled.
void mp_embed_exec_mpy(wasm_env_t *my_env, const uint8_t *mpy, size_t len);
#else
// Only available if MICROPY_PERSISTENT_CODE_LOAD is enabled.
void mp_embed_exec_mpy(const uint8_t *mpy, size_t len);
#endif

#endif

#ifdef MICROPY_WASM_LIBRARY
void near_log_message(const char *msg);
void near_log_messageN(const char *msg, size_t len);
#endif


#endif // MICROPY_INCLUDED_MICROPYTHON_EMBED_H

#include <stdint.h>

// Type definitions for the specific machine

typedef intptr_t mp_int_t; // must be pointer size
typedef uintptr_t mp_uint_t; // must be pointer size
typedef long mp_off_t;

#ifdef MICROPY_WASM_LIBRARY
//#include <alloca.h>
#include <stdlib.h>
#else
#include <stdlib.h>
#endif

// Define so there's no dependency on extmod/virtpin.h
#define mp_hal_pin_obj_t

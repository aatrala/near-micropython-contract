import json

print ("near json test program v1.0")

Dictionary ={1:'Welcome', 2:'to', 3:'Geeks', 4:'for', 5:'Geeks'}

# Our dictionary contains tuple
# as key, so it is automatically
# skipped If we have not set
# skipkeys = True then the code
# throws the error

aa_string = json.dumps(Dictionary);

#print('\n');

print('Equivalent aa string of dictionary:', aa_string);

def sum(a, b):
    return a+b

print ('Sum of two numbers 25 and 55 after calling sum is :', sum(25, 55));


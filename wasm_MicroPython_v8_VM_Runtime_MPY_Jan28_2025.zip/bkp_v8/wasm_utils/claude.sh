#!/bin/bash

# Get today's date in YYYY-MM-DD format
TODAY=$(date +%Y-%m-%d)

# Process each .c and .h file
for file in *.{c,h}; do
    # Skip if no files match pattern
    [[ -f "$file" ]] || continue
    
    # Create the dynamic comment blocks for this file
    NEW_HEADER_COMMENT=$(cat << EOF
/*
 * BEGIN
 * File name: $file
 * Date: $TODAY
 * Version: v1.0
 * 
 * Based on Micropython Embed folder
 * Converted to WASM / Near Blockchain format
 *
 * END
*/
EOF
)

    END_COMMENT="/* END OF FILE: $file */"
    
    # Create temporary file
    temp_file=$(mktemp)
    
    # Replace the first multi-line comment with our new comment
    # and add the end-of-file comment
    awk -v header="$NEW_HEADER_COMMENT" -v footer="$END_COMMENT" '
    BEGIN { in_comment = 0; replaced = 0 }
    {
        if (!replaced && $0 ~ /\/\*/) {
            in_comment = 1
            print header
            replaced = 1
            next
        }
        if (in_comment) {
            if ($0 ~ /\*\//) {
                in_comment = 0
                next
            }
            next
        }
        print $0
    }
    END 
    ' "$file" > "$temp_file"

#    END { print "\n" footer "\n" }
    
    # Replace original file with modified content
    mv "$temp_file" "$file"
    
    echo "Processed: $file"
    
done

# Concatenate all processed files into one output file
cat *.{c,h} > output_file.txt

echo "Processing complete. Results saved in output_file.txt"

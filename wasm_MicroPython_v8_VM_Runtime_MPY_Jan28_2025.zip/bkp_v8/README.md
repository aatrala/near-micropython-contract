How to Compile
==============

make -f scripts/Makefile clean; 
make -f scripts/Makefile

libmicropython/ - contains all the dependencies of micropython library

src/v8.c -> wasm interface that exports the methods that will be called from smart contract

src/main.c -> integration interface for linux ubuntu sample runtime mpy file

wasm_utils/ -> has files related to generating mpy files and hardcoding into v8.c file



emcc -I. -Imicropython_embed -Imicropython_embed/port micropython_embed/port/embed_util.c micropython_embed/port/mphalport.c micropython_embed/py/micropython.c micropython_embed/py/printf.c src/v8.c -o build/v8.wasm -s EXPORTED_FUNCTIONS='["_say_hello", "_hello_world", "_exec_python"]' --no-entry -s WASM_BIGINT -s ALLOW_MEMORY_GROWTH=0 -DMICROPY_WASM_LIBRARY -fdata-sections -ffunction-sections --target=wasm32-unknown-emscripten -s ERROR_ON_UNDEFINED_SYMBOLS=0 -s STANDALONE_WASM 
#-Oz 
#-Oz 
#-gsource-map 
#-finline-functions 
#-Oz --profiling-funcs 

#

#-s ASSERTIONS=2  


